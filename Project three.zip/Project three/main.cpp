//
//  main.cpp
//  Project three
//
//  Created by ritu mathews on 6/16/23.
//

#include <iostream>
#include <fstream>
#include <unordered_map>
#include <string>

using namespace std;

class GrocerAnalyzer {
private:
    unordered_map<string, int> itemFrequencyMap;
public:
    void ReadData(const string& filename) {
        ifstream inputFile(filename);
        if (!inputFile) {
            cout << "Error opening file: " << filename << endl;
            return;
        }

        string item;
        while (inputFile >> item) {
            itemFrequencyMap[item]++;
        }

        inputFile.close();

        // Creating a backup file
        ofstream outputFile("frequency.dat");
        if (outputFile.is_open()) {
            for (const auto& pair : itemFrequencyMap) {
                outputFile << pair.first << " " << pair.second << endl;
            }
            outputFile.close();
            cout << "Backup file created successfully.\n" << endl;
        } else {
            cout << "Unable to create backup file.\n" << endl;
        }
    }

    int GetItemFrequency(const string& item) const {
        auto it = itemFrequencyMap.find(item);
        if (it != itemFrequencyMap.end()) {
            return it->second;
        } else {
            return 0;
        }
    }

    void PrintItemFrequencies() const {
        for (const auto& pair : itemFrequencyMap) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void PrintHistogram() const {
        for (const auto& pair : itemFrequencyMap) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; i++) {
                cout << "*";
            }
            cout << endl;
        }
    }
};

int main() {
    int option;
    string Item;

    GrocerAnalyzer stuff;
    stuff.ReadData("CS210_Project_Three_Input_File.txt");

    do {
        cout << "********* Menu **********\n";
        cout << "1. Search for an item\n";
        cout << "2. Print item frequencies\n";
        cout << "3. Print histogram\n";
        cout << "4. Exit\n";
        cout << "*************************\n\n";
        cin >> option;
        
        if (cin.fail()) {
            cout << "Invalid input. Please enter a valid integer.\n";
            cin.clear(); // Clear the error state
            cin.ignore(100, '\n'); // Ignore 100 characters
            continue; // Skip to the next iteration of the loop
        }

        switch (option) {
            case 1:
                cout << "Enter the item to search: ";
                cin >> Item;
                cout << "Frequency of " << Item << ": " << stuff.GetItemFrequency(Item) << endl;
                break;
            case 2:
                stuff.PrintItemFrequencies();
                break;
            case 3:
                stuff.PrintHistogram();
                break;
            case 4:
                cout << "Exiting the program.\n";
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
        }

        cout << endl;
    } while (option != 4);

    return 0;
}
